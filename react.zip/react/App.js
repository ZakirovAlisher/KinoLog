import React, { useState, useEffect } from 'react';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  useRouteMatch,
  useParams
} from "react-router-dom";

import './bootstrap/css/bootstrap.min.css';
import EditItem from './EditItem';
import Items from './Items';
import Navbar from './Navbar';

function App() {

  return (
    <div className = "container">
      <Router>
        <Navbar/>
        <div className = "row mt-5">
          <div className = "col-12 mx-auto">
              <Switch>
                <Route path = "/login">
                  <h1>This is login page</h1>
                </Route>
                <Route path = {`/edititem/:itemId`}>
                  <EditItem/>
                </Route>
                <Route path = "/">
                  <Items/>
                </Route>
              </Switch>
          </div>
        </div>
      </Router>
    </div>
  );
}

export default App;
